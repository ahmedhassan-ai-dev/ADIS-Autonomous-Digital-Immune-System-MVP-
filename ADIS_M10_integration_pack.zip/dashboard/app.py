from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
RESULT = ROOT / "results" / "m10_final_demo.json"
M9 = ROOT / "data" / "results" / "m9_recognition_benchmark.json"
M3M4 = ROOT / "results" / "m3_m4_recognition_benchmark_v3" / "benchmark_v3.json"

st.set_page_config(
    page_title="ADIS — Digital Immune SOC",
    page_icon="🛡️",
    layout="wide",
)

st.title("🛡️ ADIS — Autonomous Digital Immune System")
st.caption("M10 Final Demonstration • Detect → Understand → Remember → Decide → Respond")

if not RESULT.exists():
    st.warning("No M10 result found yet.")
    st.code("python -m scripts.final_immune_loop")
    st.stop()

result = json.loads(RESULT.read_text(encoding="utf-8"))

detection = result.get("detection", {})
behavior = result.get("behavior", {})
recognition = result.get("recognition", {})
risk = result.get("risk", {})
decision = result.get("decision", {})
response = result.get("response", {})
latency = result.get("latency_ms", {})

c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("Detector", detection.get("detector_decision", "—"))
c2.metric("Anomaly", f"{float(detection.get('anomaly_score', 0)):.3f}")
c3.metric("Recognition", recognition.get("classification", "—"))
c4.metric("Similarity", f"{float(recognition.get('similarity', 0)):.3f}")
c5.metric("Risk", f"{float(risk.get('risk_score', 0)):.3f}")

st.divider()

left, right = st.columns(2)

with left:
    st.subheader("Immune Decision")
    st.write({
        "Behavior family": behavior.get("behavior_family"),
        "Recognition": recognition.get("classification"),
        "Policy action": recognition.get("policy_action"),
        "Risk severity": risk.get("severity"),
        "Decision Engine": decision.get("action"),
    })

with right:
    st.subheader("Response")
    st.write({
        "Status": response.get("status"),
        "Action": response.get("action"),
        "Isolation": response.get("isolation"),
    })

st.subheader("End-to-End Latency")
latency_df = pd.DataFrame(
    [{"stage": k, "milliseconds": float(v)} for k, v in latency.items()]
)
st.bar_chart(latency_df.set_index("stage"))

st.subheader("Evidence / Investigation")
investigation = result.get("investigation")
if investigation:
    if isinstance(investigation, dict) and "evidence" in investigation:
        st.dataframe(pd.DataFrame(investigation["evidence"]), use_container_width=True)
    else:
        st.json(investigation)
else:
    st.info("No investigation object was emitted for this action.")

with st.expander("M3/M4 Benchmark"):
    if M3M4.exists():
        st.json(json.loads(M3M4.read_text(encoding="utf-8")))
    else:
        st.info("M3/M4 v3 benchmark artifact not found.")

with st.expander("M9 Recognition Benchmark"):
    if M9.exists():
        st.json(json.loads(M9.read_text(encoding="utf-8")))
    else:
        st.info("M9 benchmark artifact not found.")

st.caption(
    "Prototype dashboard: evidence and metrics are derived from the local ADIS artifacts."
)

from pathlib import Path
import json, streamlit as st

ROOT=Path(__file__).resolve().parents[2]
encoder=ROOT/"models"/"behavioral_encoder.joblib"

st.title("🧠 Immune Memory")
st.caption("Persistent threat knowledge, represented as behavioral embeddings rather than static signatures.")

c=st.columns(4)
c[0].metric("Embedding","32D")
c[1].metric("Input features","77")
c[2].metric("Known threshold","≥ 0.90")
c[3].metric("Near threshold","≥ 0.75")

st.write("")
st.subheader("Recognition policy")
st.table([
    {"Similarity":"S ≥ 0.90","Class":"KNOWN","Route":"FAST_PATH"},
    {"Similarity":"0.75 ≤ S < 0.90","Class":"UNCERTAIN","Route":"INVESTIGATE"},
    {"Similarity":"S < 0.75","Class":"NOVEL","Route":"ISOLATE"},
])

st.subheader("Persistence")
mem_dirs=sorted((ROOT/"models").glob("immune_memory*"))
if mem_dirs:
    for p in mem_dirs: st.write(f"📦 `{p.relative_to(ROOT)}`")
else: st.info("No immune_memory directory is visible under models yet.")

st.markdown("""### Why it matters
A digital immune system is different from a one-shot detector: validated knowledge should remain available after
the process exits. The M8 replay/persistence stage exists specifically to test restart recognition and duplicate prevention.
""")

with st.expander("Production encoder contract"):
    st.write("Artifact:", str(encoder.relative_to(ROOT)) if encoder.exists() else "missing")
    st.write("Version: `adis-behavioral-encoder-v3-supervised`")
    st.write("Representation: `supervised_lda_plus_pca`")
    st.write("Schema hash: `aee55fd98f19d60a0bcab57ca3607eff852e2e95c315f5207ab3d66a715ed320`")

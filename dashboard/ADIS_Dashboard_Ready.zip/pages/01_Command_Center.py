from pathlib import Path
import json, time
import streamlit as st

ROOT = Path(__file__).resolve().parents[2]
RESULT = ROOT/"results"/"m10_final_demo.json"
AUDIT = ROOT/"results"/"m10_final_audit.json"

def load(p):
    try: return json.loads(p.read_text(encoding="utf-8"))
    except Exception: return {}

def num(x, default=0.0):
    try: return float(x)
    except Exception: return default

data, audit = load(RESULT), load(AUDIT)
det=data.get("detector",{}); rec=data.get("recognition",{})
risk=data.get("risk",{}); decision=data.get("decision",{})

det_score=num(det.get("score",data.get("detector_score",0)))
det_label=det.get("label",data.get("detector_label","UNKNOWN"))
family=data.get("behavior_family","—")
rec_label=rec.get("classification",data.get("recognition","—"))
sim=num(rec.get("similarity",data.get("similarity",0)))
risk_score=num(risk.get("score",data.get("risk_score",0)))
severity=risk.get("severity",data.get("severity","—"))
action=decision.get("action",data.get("decision",data.get("policy_action","—")))
memory=data.get("memory_cells",0)

st.markdown('<div class="adis-hero"><div class="adis-title">🛡️ ADIS Command Center</div><div class="adis-subtitle">Autonomous SOC view of the latest end-to-end immune decision.</div><span class="adis-chip">M10 validated</span><span class="adis-chip">M3 v3 supervised</span><span class="adis-chip">M4 persistent memory</span></div>', unsafe_allow_html=True)

c=st.columns(6)
c[0].metric("Detection",det_label,f"{det_score:.4f}")
c[1].metric("Behavior",family)
c[2].metric("Recognition",rec_label,f"S={sim:.4f}")
c[3].metric("Risk",severity,f"{risk_score:.4f}")
c[4].metric("Action",action)
c[5].metric("Memory",f"{memory} cells")

st.markdown("""<div class="pipeline">
<span class="node">Telemetry</span><span class="arrow">→</span><span class="node">M2 Detect</span><span class="arrow">→</span>
<span class="node">M3 Represent</span><span class="arrow">→</span><span class="node">M4 Remember</span><span class="arrow">→</span>
<span class="node">Risk</span><span class="arrow">→</span><span class="node">Policy</span><span class="arrow">→</span><span class="node">Response</span>
</div>""", unsafe_allow_html=True)

st.write("")
left,right=st.columns([1.15,.85])
with left:
    st.subheader("Active threat dossier")
    with st.container(border=True):
        st.write(f"**Detector:** `{det_label}` · score `{det_score:.4f}`")
        st.write(f"**Behavior:** `{family}`")
        st.write(f"**Recognition:** `{rec_label}` · similarity `{sim:.4f}`")
        st.write(f"**Risk:** `{severity}` · `{risk_score:.4f}`")
        st.write(f"**Policy action:** `{action}`")
        if rec_label=="KNOWN": st.success("Memory-assisted fast path.")
        elif rec_label=="NOVEL": st.warning("Novel behavior — investigation/isolation path.")
        else: st.info("Uncertain behavior — investigation recommended.")
with right:
    st.subheader("System health")
    checks=[
        ("Production encoder",audit.get("production_encoder",True)),
        ("Binary detector",audit.get("binary_detector",True)),
        ("Memory adapter",audit.get("memory_adapter",True)),
        ("M4 policy",audit.get("m4_policy",True)),
        ("Isolation sandbox",audit.get("isolation_sandbox",True)),
        ("M3/M4 benchmark",audit.get("m3_m4_benchmark",True)),
        ("M10 demo",audit.get("m10_demo_result",RESULT.exists())),
    ]
    for label,ok in checks: st.write(("🟢" if ok else "🔴")+f" {label}")

st.write("")
st.subheader("Decision timeline")
timeline=[
    ("M2","Innate detection",det_label,det_score),
    ("M3","Behavioral representation",family,1.0),
    ("M4","Immune recognition",rec_label,sim),
    ("RISK","Risk assessment",severity,risk_score),
    ("POLICY","Policy decision",action,1.0),
]
for stage,label,value,score in timeline:
    st.progress(max(0,min(1,score)),text=f"{stage} · {label} · {value}")

with st.expander("Raw M10 artifact"):
    st.json(data)

# ADIS Dashboard

Ready-to-run Streamlit dashboard for the ADIS Autonomous Digital Immune System MVP.

## Run

From the ADIS repository root:

```powershell
python -m streamlit run dashboard/app.py
```

The dashboard expects the repository's existing `models/`, `results/`, `src/`, and `scripts/` directories.

## Pages

- Command Center
- Immune Loop
- Immune Memory
- Benchmarks
- Project Stages
- ADIS Lab
- About ADIS
- Vision & Roadmap

The Lab only exposes repository-owned scripts through an explicit allowlist.
